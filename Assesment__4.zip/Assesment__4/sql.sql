Create table company
(
	CompanyId int Primary Key,
    Name Varchar(100),
    City varchar(100),
    Address Varchar(255)
)

Create table Students 
(
    StudentId int Primary Key,
    Name Varchar(30),
    Qualification Varchar(50),
    Skill Varchar(50)
)

insert into company(CompanyId, Name, City, Address )Values
(101, 'Apple', 'Chicago', 'New Yark'),
(102, 'CodeWorks', 'Hyderabad', '789 Street'),
(103, 'DevSolutions', 'Warangal', '101 Street');


insert into Students(StudentId, Name, Qualification, Skill )Values
(1, 'Sridhar', 'BTech', 'Python'),
(2, 'Vasu', 'BTech', 'Java'),
(3, 'Sai', 'MTech', 'SQL');

