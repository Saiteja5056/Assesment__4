﻿using System;
using System.Collections.Generic;

namespace Assaignment__4.Entities;

public partial class Gender
{
    public string? Name { get; set; }

    public string? Gender1 { get; set; }
}
