﻿using System;
using System.Collections.Generic;

namespace Assaignment__4.Entities;

public partial class Person
{
    public int? Pid { get; set; }

    public string? Pname { get; set; }
}
