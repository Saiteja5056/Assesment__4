﻿using System;
using System.Collections.Generic;

namespace Assaignment__4.Entities;

public partial class Book
{
    public int BookId { get; set; }

    public string Title { get; set; } = null!;

    public int Price { get; set; }

    public int? Volume { get; set; }

    public string? Author { get; set; }

    public DateOnly? PublishDate { get; set; }

    public int? SubjectId { get; set; }

    public virtual Subject? Subject { get; set; }
}
