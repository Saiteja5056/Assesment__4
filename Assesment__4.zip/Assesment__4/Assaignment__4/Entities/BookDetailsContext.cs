﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Assaignment__4.Entities;

public partial class BookDetailsContext : DbContext
{
    public BookDetailsContext()
    {
    }

    public BookDetailsContext(DbContextOptions<BookDetailsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Book> Books { get; set; }

    public virtual DbSet<Company> Companies { get; set; }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<EmployeeDetail> EmployeeDetails { get; set; }

    public virtual DbSet<Gender> Genders { get; set; }

    public virtual DbSet<Person> People { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<Subject> Subjects { get; set; }

    public virtual DbSet<VwBook> VwBooks { get; set; }

    public virtual DbSet<VwBook1> VwBook1s { get; set; }

    public virtual DbSet<VwBooo> VwBooos { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=LAPTOP-7592U22E\\SQLEXPRESS01;Initial Catalog=Book_Details;Integrated Security=True;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Book>(entity =>
        {
            entity.HasKey(e => e.BookId).HasName("PK__book__8BE5A10D4CAE5ADA");

            entity.ToTable("book");

            entity.Property(e => e.BookId)
                .ValueGeneratedNever()
                .HasColumnName("bookId");
            entity.Property(e => e.Author)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("author");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.PublishDate).HasColumnName("publishDate");
            entity.Property(e => e.SubjectId).HasColumnName("subjectId");
            entity.Property(e => e.Title)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("title");
            entity.Property(e => e.Volume).HasColumnName("volume");

            entity.HasOne(d => d.Subject).WithMany(p => p.Books)
                .HasForeignKey(d => d.SubjectId)
                .HasConstraintName("FK__book__subjectId__38996AB5");
        });

        modelBuilder.Entity<Company>(entity =>
        {
            entity.HasKey(e => e.CompanyId).HasName("PK__company__2D971CAC19CAAEF1");

            entity.ToTable("company");

            entity.Property(e => e.CompanyId).ValueGeneratedNever();
            entity.Property(e => e.Address)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DeptCode).HasName("PK__Departme__8985FE74BEE59F0F");

            entity.ToTable("Department");

            entity.Property(e => e.DeptCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("Dept_Code");
            entity.Property(e => e.DeptName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Dept_Name");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__employee__C52E0BA86C3CC35E");

            entity.ToTable("employee");

            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("employee_id");
            entity.Property(e => e.Designation)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("designation");
            entity.Property(e => e.JoinDate).HasColumnName("join_date");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Salary)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("salary");
        });

        modelBuilder.Entity<EmployeeDetail>(entity =>
        {
            entity.HasKey(e => e.EmpId).HasName("PK__Employee__AF2DBA79E9B60607");

            entity.Property(e => e.EmpId)
                .ValueGeneratedNever()
                .HasColumnName("EmpID");
            entity.Property(e => e.DeptCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("Dept_Code");
            entity.Property(e => e.Designation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmpName)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.DeptCodeNavigation).WithMany(p => p.EmployeeDetails)
                .HasForeignKey(d => d.DeptCode)
                .HasConstraintName("FK__EmployeeD__Dept___2CF2ADDF");
        });

        modelBuilder.Entity<Gender>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Gender");

            entity.Property(e => e.Gender1)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("gender");
            entity.Property(e => e.Name)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Person>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("person");

            entity.HasIndex(e => e.Pname, "p_name");

            entity.Property(e => e.Pid).HasColumnName("pid");
            entity.Property(e => e.Pname)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("pname");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Pid).HasName("PK__product__DD37D91A3E963B60");

            entity.ToTable("product");

            entity.HasIndex(e => e.Pname, "UQ__product__1FC9734C4996F9DF").IsUnique();

            entity.Property(e => e.Pid)
                .ValueGeneratedNever()
                .HasColumnName("pid");
            entity.Property(e => e.Pname)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("pname");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.Stock).HasColumnName("stock");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("PK__Students__32C52B99EEEFCD1A");

            entity.Property(e => e.StudentId).ValueGeneratedNever();
            entity.Property(e => e.Name)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Qualification)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Skill)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Subject>(entity =>
        {
            entity.HasKey(e => e.SubjectId).HasName("PK__Subject__ACF9A76023A13930");

            entity.ToTable("Subject");

            entity.Property(e => e.SubjectId)
                .ValueGeneratedNever()
                .HasColumnName("subjectId");
            entity.Property(e => e.Subtitle)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("subtitle");
        });

        modelBuilder.Entity<VwBook>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_book");

            entity.Property(e => e.BookId).HasColumnName("bookId");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.Title)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("title");
            entity.Property(e => e.Volume).HasColumnName("volume");
        });

        modelBuilder.Entity<VwBook1>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_book1");

            entity.Property(e => e.BookId).HasColumnName("bookId");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.Title)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<VwBooo>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("vw_booo");

            entity.Property(e => e.BookId).HasColumnName("bookId");
            entity.Property(e => e.SubjectId).HasColumnName("subjectId");
            entity.Property(e => e.Title)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
