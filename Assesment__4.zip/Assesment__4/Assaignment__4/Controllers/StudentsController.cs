﻿using Assaignment__4.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Assaignment__4.Controllers
{
    public class StudentsController : Controller
    {
        private readonly BookDetailsContext bookDetailsContext;
        public StudentsController()
        {
            bookDetailsContext = new BookDetailsContext();
        }
        [HttpGet]
        public IActionResult Index()
        {
            var students = bookDetailsContext.Students;
            return View(students);
        }
        public IActionResult AddStudent()
        {

            return View();
        }
        [HttpPost]
        public IActionResult AddStudent(Student student)
        {
            if (ModelState.IsValid)
            {
                bookDetailsContext.Students.Add(student);
                bookDetailsContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var student = bookDetailsContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {

            bookDetailsContext.Students.Remove(student);
            bookDetailsContext.SaveChanges();
            return RedirectToAction("Index");

        }
        [HttpGet]
        public IActionResult UpdateStudent(int id)
        {
            var student = bookDetailsContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult UpdateStudent(Student student)
        {
            if (ModelState.IsValid)
            {
                bookDetailsContext.Students.Update(student);
                bookDetailsContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
        }
        [HttpGet]
        public IActionResult Detailsbyid(int id)
        {
            var student = bookDetailsContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
    }
}
